﻿namespace P04_BorderControl.Interfaces
{
    public interface IRobot : IIdentifyable
    {
        string Model { get; }
    }
}
