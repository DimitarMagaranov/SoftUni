﻿namespace P04_BorderControl.Interfaces
{
    public interface IBuyer
    {
        int Food { get; }

        void BuyFood();
    }
}
