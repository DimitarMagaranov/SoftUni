﻿namespace P04_BorderControl.Interfaces
{
    public interface IBirthable
    {
        string Birthdate { get; }
    }
}
