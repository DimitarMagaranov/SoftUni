﻿namespace P04_BorderControl.Interfaces
{
    public interface IPet : IBirthable
    {
        string Name { get; }
    }
}
