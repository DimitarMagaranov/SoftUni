﻿namespace P04_BorderControl.Interfaces
{
    public interface IIdentifyable
    {
        string Id { get; }
    }
}
