﻿namespace P07_MilitaryElite.Contracts
{
    public interface ISpy
    {
        int CodeNumber { get; }
    }
}
