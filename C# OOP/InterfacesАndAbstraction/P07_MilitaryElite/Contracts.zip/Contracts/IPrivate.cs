﻿namespace P07_MilitaryElite.Contracts
{
    public interface IPrivate
    {
        decimal Salary { get; }
    }
}
