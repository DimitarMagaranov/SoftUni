﻿namespace P07_MilitaryElite.Contracts.Privates
{
    public interface ISpecialisedSoldier
    {
        string Corps { get; }
    }
}
