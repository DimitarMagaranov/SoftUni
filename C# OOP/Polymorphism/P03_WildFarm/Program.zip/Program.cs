﻿using P03_WildFarm.Models;

namespace P03_WildFarm
{
    public class Program
    {
        public static void Main()
        {
            Engine engine = new Engine();

            engine.Run();
        }
    }
}
