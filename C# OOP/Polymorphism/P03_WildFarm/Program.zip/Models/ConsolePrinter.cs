﻿using System;

namespace P03_WildFarm.Models
{
    public static class ConsolePrinter
    {
        public static void Print(string message)
        {
            Console.WriteLine(message);
        }
    }
}
