﻿using P01_Vehicles.Models;

namespace P01_Vehicles
{
    public class Program
    {
        static void Main(string[] args)
        {
            Engine engine = new Engine();

            engine.Run();
        }
    }
}
