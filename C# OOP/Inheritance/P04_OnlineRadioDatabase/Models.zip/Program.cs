﻿namespace P04_OnlineRadioDatabase
{
    using System;
    using P04_OnlineRadioDatabase.Models;

    public class Program
    {
        public static void Main()
        {
            Engine engine = new Engine();

            engine.Run();
        }
    }
}
