﻿using MXGP.Core.Contracts;
using MXGP.Models.Motorcycles.Contracts;
using MXGP.Models.Motorcycles.Models;
using MXGP.Models.Races.Contracts;
using MXGP.Models.Races.Models;
using MXGP.Models.Riders.Contracts;
using MXGP.Models.Riders.Models;
using MXGP.Repositories;
using MXGP.Repositories.Contracts.Models;
using MXGP.Repositories.Models;
using MXGP.Utilities.Messages;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;

namespace MXGP.Core.Models
{
    public class ChampionshipController : IChampionshipController
    {
        private const int MinRaceParticipants = 3;

        private readonly IRepository<IRider> riderRepository;
        private readonly IRepository<IMotorcycle> motorcycleRepository;
        private readonly IRepository<IRace> raceRepository;

        public ChampionshipController()
        {
            this.riderRepository = new RiderRepository();
            this.motorcycleRepository = new MotorcycleRepository();
            this.raceRepository = new RaceRepository();
        }

        public string AddMotorcycleToRider(string riderName, string motorcycleModel)
        {
            IMotorcycle motorcycle = this.motorcycleRepository.GetByName(motorcycleModel);
            IRider rider = this.riderRepository.GetByName(riderName);

            if (motorcycle == null)
            {
                throw new InvalidOperationException(string.Format(ExceptionMessages.MotorcycleNotFound, motorcycleModel));
            }

            if (rider == null)
            {
                throw new InvalidOperationException(string.Format(ExceptionMessages.RiderNotFound, riderName));
            }

            rider.AddMotorcycle(motorcycle);

            return string.Format(OutputMessages.MotorcycleAdded, riderName, motorcycleModel);
        }

        public string AddRiderToRace(string raceName, string riderName)
        {
            IRace race = this.raceRepository.GetByName(raceName);
            IRider rider = this.riderRepository.GetByName(riderName);

            if (race == null)
            {
                throw new InvalidOperationException(string.Format(ExceptionMessages.RaceNotFound, raceName));
            }

            if (rider == null)
            {
                throw new InvalidOperationException(string.Format(ExceptionMessages.RiderNotFound, riderName));
            }

            race.AddRider(rider);

            return string.Format(OutputMessages.RiderAdded, riderName, raceName);
        }

        public string CreateMotorcycle(string type, string model, int horsePower)
        {
            IMotorcycle motorcycle = this.motorcycleRepository.GetByName(model);

            if (motorcycle != null)
            {
                throw new ArgumentException(string.Format(ExceptionMessages.MotorcycleExists, model));
            }

            if (type == "SpeedMotorcycle")
            {
                motorcycle = new SpeedMotorcycle(model, horsePower);
            }
            else if (type == "PowerMotorcycle")
            {
                motorcycle = new PowerMotorcycle(model, horsePower);
            }
            
            this.motorcycleRepository.Add(motorcycle);

            return string.Format(OutputMessages.MotorcycleCreated, type, model);
        }

        public string CreateRace(string name, int laps)
        {
            var race = this.raceRepository.GetByName(name);

            if (race != null)
            {
                throw new InvalidOperationException(string.Format(ExceptionMessages.RaceExists, name));
            }

            race = new Race(name, laps);

            this.raceRepository.Add(race);

            return string.Format(OutputMessages.RaceCreated, name);
        }

        public string CreateRider(string riderName)
        {
            IRider rider = this.riderRepository.GetByName(riderName);

            if (rider != null)
            {
                throw new ArgumentException(string.Format(ExceptionMessages.RiderExists, riderName));
            }

            rider = new Rider(riderName);

            this.riderRepository.Add(rider);

            return string.Format(OutputMessages.RiderCreated, riderName);
        }

        public string StartRace(string raceName)
        {
            IRace race = this.raceRepository.GetByName(raceName);

            if (race == null)
            {
                throw new InvalidOperationException(string.Format(ExceptionMessages.RaceNotFound, raceName));
            }

            if (race.Riders.Count() < MinRaceParticipants)
            {
                throw new InvalidOperationException(string.Format(ExceptionMessages.RaceInvalid, raceName, MinRaceParticipants));
            }

            List<IRider> orderedRiders = race.Riders
                .OrderByDescending(x => x.Motorcycle.CalculateRacePoints(race.Laps))
                .Take(MinRaceParticipants)
                .ToList();

            IRider firstRider = orderedRiders[0];
            IRider secondRider = orderedRiders[1];
            IRider thirdRider = orderedRiders[2];

            StringBuilder stringBuilder = new StringBuilder();

            stringBuilder.AppendLine(string.Format(OutputMessages.RiderFirstPosition, firstRider.Name, race.Name));
            stringBuilder.AppendLine(string.Format(OutputMessages.RiderSecondPosition, secondRider.Name, race.Name));
            stringBuilder.AppendLine(string.Format(OutputMessages.RiderThirdPosition, thirdRider.Name, race.Name));

            this.raceRepository.Remove(race);

            return stringBuilder.ToString().TrimEnd();
        }
    }
}
