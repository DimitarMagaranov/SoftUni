﻿namespace ViceCity.Models.Players.Models
{
    public class MainPlayer : Player
    {
        public MainPlayer()
            : base("Tommy Vercetti", 100)
        {
        }
    }
}
