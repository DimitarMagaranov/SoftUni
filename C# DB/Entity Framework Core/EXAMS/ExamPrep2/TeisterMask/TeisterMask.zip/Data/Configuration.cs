﻿namespace TeisterMask.Data
{
    public static class Configuration
    {
        public static string ConnectionString = @"Server=DESKTOP-GPNJISJ\SQLEXPRESS;Database=TeisterMask;Trusted_Connection=True";
    }
}
