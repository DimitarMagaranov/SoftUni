﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P01_HospitalDatabase.Data
{
    internal static class Configuration
    {
        internal static string ConnectionString = @"Server=DESKTOP-GPNJISJ\SQLEXPRESS;Database=HospitalDatabase;Integrated Security=True;";
    }
}
