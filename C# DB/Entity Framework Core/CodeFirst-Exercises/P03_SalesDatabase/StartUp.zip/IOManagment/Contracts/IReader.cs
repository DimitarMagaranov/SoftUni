﻿namespace P03_SalesDatabase.IOManagment.Contracts
{
    public interface IReader
    {
        string ReadLine();
    }
}
