﻿using System;

using P03_SalesDatabase.IOManagment.Contracts;

namespace P03_SalesDatabase.IOManagment
{
    public class ConsoleWriter : IWriter
    {
        public void Write(string text)
        {
            Console.Write(text);
        }

        public void WriteLine(string text)
        {
            Console.WriteLine(text);
        }
    }
}
