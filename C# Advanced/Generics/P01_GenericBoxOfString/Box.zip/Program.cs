﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace P01_GenericBoxOfString
{
    public class Program
    {
        static void Main()
        {
            int countOfElements = int.Parse(Console.ReadLine());

            Box<int> box = new Box<int>();

            for (int i = 0; i < countOfElements; i++)
            {
                box.Elements.Add(int.Parse(Console.ReadLine()));
            }

            List<int> indexes = Console.ReadLine().Split().Select(int.Parse).ToList();

            int index1 = indexes[0];
            int index2 = indexes[1];

            box.Swap(index1, index2);

            Console.WriteLine(box);
        }
    }
}
