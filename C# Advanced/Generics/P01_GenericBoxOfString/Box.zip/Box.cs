﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P01_GenericBoxOfString
{
    public class Box<T>
    {
        public Box()
        {
            this.Elements = new List<T>();
        }

        public List<T> Elements { get; set; }

        public void Swap(int index1, int index2)
        {
            var temp = this.Elements[index1];
            this.Elements[index1] = this.Elements[index2];
            this.Elements[index2] = temp;
        }

        public override string ToString()
        {
            StringBuilder stringBuilder = new StringBuilder();

            foreach (var element in Elements)
            {
                stringBuilder.AppendLine($"{element.GetType()}: {element}");
            }

            return stringBuilder.ToString();
        }
    }
}
