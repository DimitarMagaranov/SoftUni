﻿namespace _02.LowestCommonAncestor
{
    using System;
    using System.Collections.Generic;

    public class BinaryTree<T> : IAbstractBinaryTree<T>
        where T : IComparable<T>
    {
        public BinaryTree(
            T value,
            BinaryTree<T> leftChild,
            BinaryTree<T> rightChild)
        {
            this.Value = value;
            this.LeftChild = leftChild;
            this.RightChild = rightChild;

            if (this.LeftChild != null)
            {
                this.LeftChild.Parent = this;
            }

            if (this.RightChild != null)
            {
                this.RightChild.Parent = this;
            }
        }

        public T Value { get; set; }

        public BinaryTree<T> LeftChild { get; set; }

        public BinaryTree<T> RightChild { get; set; }

        public BinaryTree<T> Parent { get; set; }

        //public T FindLowestCommonAncestor(T first, T second)
        //{
        //    var firstList = new List<BinaryTree<T>>();
        //    var secondList = new List<BinaryTree<T>>();

        //    this.FindNodeDfs(this, first, firstList);
        //    this.FindNodeDfs(this, second, secondList);

        //    var firstNode = firstList[0];
        //    var secondNode = secondList[0];

        //    var parentValueToLookFor = firstNode.Parent.Value;

        //    while (parentValueToLookFor.Equals(firstNode.Value) == false
        //        || parentValueToLookFor.Equals(secondNode.Value) == false)
        //    {
        //        if (parentValueToLookFor.Equals(firstNode.Value) == false)
        //        {
        //            firstNode = firstNode.Parent;
        //        }

        //        if (parentValueToLookFor.Equals(secondNode.Value) == false)
        //        {
        //            secondNode = secondNode.Parent;
        //        }
        //    }

        //    return firstNode.Value;
        //}

        public T FindLowestCommonAncestor(T first, T second)
        {
            var firstList = new List<BinaryTree<T>>();
            var secondList = new List<BinaryTree<T>>();

            this.FindNodeDfs(this, first, firstList);
            this.FindNodeDfs(this, second, secondList);

            var firstNode = firstList[0];
            var secondNode = secondList[0];

            var current = secondNode;

            while (current.Parent != null)
            {
                secondList.Add(current.Parent);
                current = current.Parent;
            }

            var lookup = firstNode;

            while (lookup != null)
            {
                if (secondList.Contains(lookup))
                {
                    return lookup.Value;
                }
                lookup = lookup.Parent;
            }

            return default;
        }

        private void FindNodeDfs(BinaryTree<T> current, T lookupValue, List<BinaryTree<T>> result)
        {
            if (current == null)
            {
                return;
            }

            if (current.Value.Equals(lookupValue))
            {
                result.Add(current);
                return;
            }

            this.FindNodeDfs(current.LeftChild, lookupValue, result);
            this.FindNodeDfs(current.RightChild, lookupValue, result);
        }
    }
}
